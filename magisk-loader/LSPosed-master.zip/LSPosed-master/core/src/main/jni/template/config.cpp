#include "config.h"

namespace lspd {
const int versionCode = ${VERSION_CODE};
const char* const versionName = "${VERSION_NAME}";
}
