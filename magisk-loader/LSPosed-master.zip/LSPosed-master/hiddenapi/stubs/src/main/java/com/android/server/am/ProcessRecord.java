package com.android.server.am;

public class ProcessRecord {
    String processName = null;
}
