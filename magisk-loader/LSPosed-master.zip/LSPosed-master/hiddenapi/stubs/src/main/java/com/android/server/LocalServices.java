package com.android.server;

public class LocalServices {

    public static <T> T getService(Class<T> type) {
        throw new UnsupportedOperationException("STUB");
    }
}
