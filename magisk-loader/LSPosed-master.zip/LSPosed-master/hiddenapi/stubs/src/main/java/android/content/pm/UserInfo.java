package android.content.pm;

public class UserInfo {
    public int id;
    public String name;
}
