package android.os;

public class Parcel {
}
