package android.content.res;

import java.io.IOException;
import java.io.InputStream;

public final class AssetManager {
	public final int addAssetPath(String path) {
		throw new UnsupportedOperationException("STUB");
	}

	public void close() {
		throw new UnsupportedOperationException("STUB");
	}

	public final InputStream open(String fileName) throws IOException {
		throw new UnsupportedOperationException("STUB");
	}
}
