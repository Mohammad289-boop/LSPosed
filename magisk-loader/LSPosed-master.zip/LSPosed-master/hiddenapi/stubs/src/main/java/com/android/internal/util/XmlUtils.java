package com.android.internal.util;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;

public class XmlUtils {
	@SuppressWarnings("rawtypes")
	public static final HashMap readMapXml(InputStream in) throws XmlPullParserException, IOException {
		throw new UnsupportedOperationException("STUB");
	}
}
