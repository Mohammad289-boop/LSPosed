package android.content;

public class AttributionSource {
}
