package android.content.pm;

import java.util.List;

abstract class BaseParceledListSlice<T> {

    public List<T> getList() {
        throw new RuntimeException("STUB");
    }
}
