package sun.net.www.protocol.jar;

public abstract class Handler extends java.net.URLStreamHandler {
}
