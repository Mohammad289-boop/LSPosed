package android.content.pm;

import java.util.List;

public class PackageManager {
    public List<PackageInfo> getInstalledPackagesAsUser(int flags, int userId) {
        throw new UnsupportedOperationException("STUB");
    }

}
