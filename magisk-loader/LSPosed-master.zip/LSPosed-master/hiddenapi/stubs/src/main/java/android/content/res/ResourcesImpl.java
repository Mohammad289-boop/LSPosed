package android.content.res;

public class ResourcesImpl {
}
