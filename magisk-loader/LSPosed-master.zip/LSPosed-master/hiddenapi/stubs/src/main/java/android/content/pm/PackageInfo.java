package android.content.pm;

public class PackageInfo {

    public String overlayTarget;
}
