package android.os;

import android.annotation.NonNull;

public class UserHandle {

    public UserHandle(int h) {
        throw new RuntimeException("STUB");
    }

    public int getIdentifier() {
        throw new RuntimeException("STUB");
    }

    public static final @NonNull
    UserHandle ALL = null;
}
