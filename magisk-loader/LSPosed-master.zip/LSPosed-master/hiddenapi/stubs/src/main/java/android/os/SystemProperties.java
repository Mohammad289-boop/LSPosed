package android.os;

import android.annotation.NonNull;
import android.annotation.Nullable;

public class SystemProperties {
    public static String get(@NonNull String key) {
        throw new UnsupportedOperationException("Stub");
    }

    public static String get(@NonNull String key, @Nullable String def) {
        throw new UnsupportedOperationException("Stub");
    }

    public static void set(@NonNull String key, @Nullable String val) {
        throw new UnsupportedOperationException("Stub");
    }

    public static boolean getBoolean(@NonNull String key, boolean def) {
        throw new UnsupportedOperationException("Stub");
    }

    public static int getInt(@NonNull String key, int def) {
        throw new UnsupportedOperationException("Stub");
    }
}
