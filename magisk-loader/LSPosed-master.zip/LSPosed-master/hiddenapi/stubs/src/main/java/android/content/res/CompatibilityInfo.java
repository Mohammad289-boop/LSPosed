package android.content.res;

public class CompatibilityInfo {
}
